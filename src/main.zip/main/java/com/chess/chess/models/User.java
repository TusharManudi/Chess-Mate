package com.chess.chess.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "app_user")
@Getter
@Setter
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id ;

    @Column(nullable = false)
    private String username ;

    @Column(nullable = false,unique = true)
    private String email ;

    @Column(nullable = false)
    private String password ;

    private int rating = 500 ; //chess elo

    @OneToMany(mappedBy = "white")
    private List<Game> gamesAsWhite ;

    @OneToMany(mappedBy = "black")
    private List<Game> gamesAsBlack ;

}
