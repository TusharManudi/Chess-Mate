package com.chess.chess.models;

public enum GameStatus {
    WAITING, IN_GAME , FINISHED
}
