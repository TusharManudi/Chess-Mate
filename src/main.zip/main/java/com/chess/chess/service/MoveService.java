package com.chess.chess.service;

import org.springframework.stereotype.Service;

@Service
public class MoveService {
}
