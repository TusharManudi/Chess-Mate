package com.chess.chess.service;

import com.chess.chess.models.User;
import com.chess.chess.repo.UserRepo;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepo userRepo;
    public String createUser(String email) {
        User user = new User() ;
        user.setEmail(email) ;
        user.setPassword("password") ;
        user.setUsername("User"+email) ;
        userRepo.save(user) ;
        return user.getId().toString() ;

    }
}
