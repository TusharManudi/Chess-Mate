package com.chess.chess.config;

import com.chess.chess.service.JWTService;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class JWTAuthenticationFilter extends OncePerRequestFilter {

    private final JWTService jwtService ;
    private final CustomUserDetailsService userDetailsService;

    public JWTAuthenticationFilter(JWTService jwtService , CustomUserDetailsService userDetailsService ){
        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
    }

}
