package com.chess.chess.controller;

import com.chess.chess.dto.RegisterDto;
import com.chess.chess.models.User;
import com.chess.chess.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/create")
    public ResponseEntity<?> createUser(@RequestBody String email){
        String id = userService.createUser(email) ;
        return new ResponseEntity<>(id , HttpStatus.CREATED) ;
    }

    @PostMapping("/createuser")
    public ResponseEntity<?> createUser(@RequestBody RegisterDto player){
        User user = new User() ;
        user.setUsername(player.getUsername());
        user.setPassword(player.getPassword());
        user.setEmail(player.getEmail());


    }
}
