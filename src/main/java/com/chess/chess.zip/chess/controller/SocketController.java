package com.chess.chess.controller;

import com.chess.chess.dto.GameStartNotification;
import com.chess.chess.dto.JoinRequest;
import com.chess.chess.dto.JoinResponse;
import com.chess.chess.dto.MoveRequest;
import com.chess.chess.models.GameStatus;
import com.chess.chess.service.GameService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.util.Map;
import java.util.Objects;

@Controller

public class SocketController {
    @Autowired
    private GameService gameService;
    @Autowired
    private SimpMessagingTemplate messagingTemplate;




    @MessageMapping("/join")
    public void handleJoinGame(JoinRequest request){
//        JoinResponse response = gameService.joinOrCreateGame(request.getUserId());
//
//        // Always send join response to the requesting user
//        messagingTemplate.convertAndSendToUser(
//                request.getUserId().toString(),
//                "/queue/join-response",
//                response
//        );
//
//        // If the game just started (2nd player joined), notify both players
//        if (response.getGameStatus() == GameStatus.IN_GAME && response.getOpponentId() != null) {
//            // Notify the current player
//            GameStartNotification notification = GameStartNotification.builder()
//                    .opponentId(response.getOpponentId())
//                    .gameId(response.getGameId())
//                    .fen(response.getFen())
//                    .yourColor(response.getAssignedColor())
//                    .build();
//
//            messagingTemplate.convertAndSendToUser(
//                    request.getUserId().toString(),
//                    "/queue/game-start",
//                    notification
//            );
//
//            // Determine opponent’s color
//            String opponentColor = response.getAssignedColor().equals("Black") ? "White" : "Black";
//
//            // Notify the opponent
//            GameStartNotification opponentNotification = GameStartNotification.builder()
//                    .opponentId(request.getUserId())
//                    .gameId(response.getGameId())
//                    .fen(response.getFen())
//                    .yourColor(opponentColor)
//                    .build();
//
//            messagingTemplate.convertAndSendToUser(
//                    response.getOpponentId().toString(),
//                    "/queue/game-start",
//                    opponentNotification
//            );
//
//            // Broadcast to topic (optional)
//            messagingTemplate.convertAndSend(
//                    "/topic/game." + response.getGameId() + ".start",
//                    Map.of("gameId", response.getGameId(), "status", "IN_PROGRESS")
//            );
//        }


        JoinResponse response = gameService.joinOrCreateGame(request.getUserId());

        // Send join response to topic instead of user queue
        messagingTemplate.convertAndSend(
                "/topic/join-response-" + request.getUserId().toString(),
                response
        );

        // If the game just started (2nd player joined), notify both players
        if (response.getGameStatus() == GameStatus.IN_GAME && response.getOpponentId() != null) {
            // Notify the current player
            GameStartNotification notification = GameStartNotification.builder()
                    .opponentId(response.getOpponentId())
                    .gameId(response.getGameId())
                    .fen(response.getFen())
                    .yourColor(response.getAssignedColor())
                    .build();

            messagingTemplate.convertAndSend(
                    "/topic/game-start-" + request.getUserId().toString(),
                    notification
            );

            // Determine opponent's color
            String opponentColor = response.getAssignedColor().equals("Black") ? "White" : "Black";

            // Notify the opponent
            GameStartNotification opponentNotification = GameStartNotification.builder()
                    .opponentId(request.getUserId())
                    .gameId(response.getGameId())
                    .fen(response.getFen())
                    .yourColor(opponentColor)
                    .build();

            messagingTemplate.convertAndSend(
                    "/topic/game-start-" + response.getOpponentId().toString(),
                    opponentNotification
            );
        }
    }
}
